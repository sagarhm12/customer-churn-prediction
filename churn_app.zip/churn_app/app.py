import streamlit as st
import pandas as pd
import joblib
from utils.preprocessing import preprocess_input

st.set_page_config(page_title="Churn Predictor", layout="centered")
st.title("🏦 Customer Churn Prediction App")

model = joblib.load(r"C:\Users\DEEPAK TR\OneDrive\Desktop\churn_app\model\churn_model.pkl")

uploaded_file = st.file_uploader("Upload CSV file with customer data", type=["csv"])

if uploaded_file:
    data = pd.read_csv(uploaded_file)
    st.subheader("📋 Uploaded Data Preview")
    st.dataframe(data.head())

    # Drop unwanted columns before prediction
    data_for_model = data.drop(columns=["customer_id", "churn"], errors="ignore")

    try:
        processed = preprocess_input(data_for_model)
        predictions = model.predict(processed)
        probabilities = model.predict_proba(processed)[:, 1]

        data["Churn"] = predictions
        data["Churn_Probability (%)"] = (probabilities * 100).round(2)

        st.subheader("📊 Prediction Results")
        st.dataframe(data[["customer_id", "Churn", "Churn_Probability (%)"]])

        st.download_button("📥 Download CSV", data.to_csv(index=False), file_name="churn_predictions.csv")

    except Exception as e:
        st.error(f"🚨 Error during processing: {e}")
