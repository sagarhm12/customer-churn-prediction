
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib
from utils.preprocessing import preprocess_input

# Load data
df = pd.read_csv(r'C:\Users\DEEPAK TR\OneDrive\Desktop\churn_app\data\Bank Customer Churn Prediction.csv')

# Drop 'customer_id' and 'churn' for features
X = df.drop(columns=["customer_id", "churn"])
y = df["churn"]

# Preprocess
X_processed = preprocess_input(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_processed, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Save model
joblib.dump(model, r"C:\Users\DEEPAK TR\OneDrive\Desktop\churn_app\model\churn_model.pkl")  # Ensure 'model/' folder exists
print("✅ Model saved as 'model/churn_model.pkl'")

print("✅ Model training complete and saved.")

