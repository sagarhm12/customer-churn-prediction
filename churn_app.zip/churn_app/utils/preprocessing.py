import pandas as pd

def preprocess_input(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Encode Gender
    df["Gender"] = df["Gender"].map({"Male": 1, "Female": 0})

    # One-hot encode country
    df = pd.get_dummies(df, columns=["country"], drop_first=True)

    return df
